$(document).ready(function(){
	$(".in_button").click(function(){
		var str = document.getElementById("in_text").value;//input框的内容
		alert(str);
	});
})
