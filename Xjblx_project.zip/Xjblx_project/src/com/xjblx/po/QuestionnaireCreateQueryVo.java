/**
 * 
 * @author		
 */
package com.xjblx.po;

/**
 * 
 * <p>Title: </p>
 * <p>Description: </p>
 * @author	
 * @date	
 * @version 
 */
public class QuestionnaireCreateQueryVo {
	private QuestionnaireCreate questionnaireCreate;
	private QuestionnaireCreateCustom questionnaireCreateCustom;
	public QuestionnaireCreate getQuestionnaireCreate() {
		return questionnaireCreate;
	}
	public void setQuestionnaireCreate(QuestionnaireCreate questionnaireCreate) {
		this.questionnaireCreate = questionnaireCreate;
	}
	public QuestionnaireCreateCustom getQuestionnaireCreateCustom() {
		return questionnaireCreateCustom;
	}
	public void setQuestionnaireCreateCustom(QuestionnaireCreateCustom questionnaireCreateCustom) {
		this.questionnaireCreateCustom = questionnaireCreateCustom;
	}
	
}
