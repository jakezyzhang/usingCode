package com.xjblx.po;
/**
 * 
 * <p>Title: CustomDateConverter</p>
 * <p>Description:User的pojo的扩展类 </p>
 * <p>Company: www.itcast.com</p> 
 * @author	张子阳
 * @date	2018-4-18
 * @version 1.0
 */
public class UserCustom extends User{
	
	
	
}
