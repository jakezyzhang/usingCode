/**
 * 
 * @author		
 */
package com.xjblx.po;

/**
 * 
 * <p>Title: QustionnaireCustom</p>
 * <p>Description: 问卷的扩展类</p>
 * @author	zhangziyang
 * @date	2018/5/1	
 * @version 1.2
 */
public class QustionnaireCustom extends Questionnaire {
	
	
	
}
