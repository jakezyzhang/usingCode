/**
 * 
 * @author		
 */
package com.xjblx.po;

/**
 * 
 * <p>Title: </p>
 * <p>Description: </p>
 * @author	
 * @date	
 * @version 
 */
public class QuestionnaireCreateCustom extends QuestionnaireCreate {

}
